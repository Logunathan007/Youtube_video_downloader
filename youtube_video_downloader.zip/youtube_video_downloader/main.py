import subprocess

def again_run():
    input_link = str(input("\n Enter a Youtube video link: "))
    if ('playlist?list=' not in input_link) and ('youtu' in input_link):
        print("\n We are finding best resolution ...")
        print("\n Ready To Download")
        print("\n Don't close tab download started \n \n")
        sub_link = ['youtube-dl','-f','18',input_link]
        subprocess.run(sub_link)
        again_run()
    elif ("playlist?list=" in input_link) and ('youtu' in input_link):
        print("\n ",dict([(1,"If you want to download full playlist"),(2,"Download specific videos in playlist")]))
        direction = str(input("\n Press 1 or 2: "))
        if direction == '1':
            print("\n We are finding best resolution ...")
            print("\n Ready To Download")
            print("\n Don't close tab download started \n ")
            sub_link = ['youtube-dl', '-f', "18", input_link]
            subprocess.run(sub_link)
            again_run()
        elif direction == '2':
            print("""\n Available playlist types are : \n\tWrite a custom number like, 1, 7, 4, 3 \t(or)  Ordered playlist like, 1 to 10 ,8 to 17""")
            video_no = input("\n Enter a video Identity in numbers: ")
            if 'to' in video_no:
                split_no = video_no.split('to')
                split_link = ['youtube-dl', '-f', '18', '--playlist-start', split_no[0], '--playlist-end',split_no[1], input_link]
            elif video_no != '':
                split_link = ['youtube-dl', '-f', '18', "--playlist-items", video_no,input_link]
            else:
                again_run()
            subprocess.run(split_link)
            again_run()
        else:
            print("\n Type correctly... ")
            again_run()
    elif input_link in ('tata','bye','Tata','Bye','TATA',"bye"):
    	print("\n Tata...\n\n")
    	
    else:
        print("\n Enter a Valit link...")
        again_run()
again_run()
